def main():
    import discotp.bot